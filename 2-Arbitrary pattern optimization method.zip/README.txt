To use this design method, the analysis software Aplanar is needed (both should be in the same folder).

In order to start the procedure, the function "Optim.m" has to be executed.

A .mat file with information about the antenna structure is required to design a new antenna. An example of this file can be found in the folder "mat files".